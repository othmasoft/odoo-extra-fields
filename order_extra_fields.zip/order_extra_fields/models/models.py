# -*- coding: utf-8 -*-

from odoo import models, fields


class sale_extra_fields(models.Model):
    _name = 'sale.order'
    _inherit = 'sale.order'

    order_id = fields.Integer('Order ID')
    manufacture = fields.Char('Manufacture')
    payment_code = fields.Char('Payment Code')

    _sql_constraints = [
        ('order_id_uniq', 'unique (order_id)', "The Order already exists with this ID . ID must be unique!"),
    ]
