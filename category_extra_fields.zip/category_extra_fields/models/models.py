# -*- coding: utf-8 -*-

from odoo import models, fields


class category_extra_fields(models.Model):
    _name = 'product.category'
    _inherit = 'product.category'

    category_id = fields.Integer('category ID', required=True, index=True, translate=True)

    _sql_constraints = [
        ('category_id_uniq', 'unique (category_id)', "A category already exists with this ID . ID must be unique!"),
    ]
