from odoo import models, fields


class customer_extra_fields(models.Model):
    _name = 'res.partner'
    _inherit = 'res.partner'

    customer_id = fields.Integer('customer ID', required=True, index=True, translate=True)

    _sql_constraints = [
        ('customer_id_uniq', 'unique (customer_id)', "A Customer already exists with this ID . ID must be unique!"),
    ]
